package application;
	
import java.util.*; //For ArrayList, etc...
import java.io.*; //input/output
import java.util.ArrayList;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) throws IOException {
		Parent root= FXMLLoader.load(getClass().getResource("SimpleMerge.fxml"));//fxml���Ͽ��� ������ �޾ƿ�
		primaryStage.setScene(new Scene(root));
		primaryStage.setTitle("Simple Merge");//Title
		primaryStage.show();// �� �ڵ尡 �־�� GUI����
		primaryStage.setResizable(false);
}
	
	public static void main(String[] args) throws IOException {
		
		/*Input Text*/
	    FileReader file_reader;
	    BufferedReader buffer_reader;
	    String string;
	    ArrayList<String> input;
	    String name_of_code = "Input.txt";
	    input = new ArrayList<String>();
	    input.clear();
	    file_reader = new FileReader(name_of_code);
	    buffer_reader = new BufferedReader(file_reader);
	    for (int i = 0; (string = buffer_reader.readLine())!= null; i++ ) {
         input.add(string);
	    }
	    string = "";
	    /*for (int i = 0; i < input.size(); i++) {
	    string += input.get(i); //REad
	    }*/
	    for (int i = 0; i < input.size(); i++) {
	    System.out.println(input.get(i));
	    }
	    file_reader.close();
	    
	    /*Start GUI*/
		launch(args);
	}
}
